import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { TranslateLoader, TranslateModule} from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';

import { HttpClient, HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { ParrafoComponent } from './parrafo/parrafo.component';
import { ParrafoComponent2 } from './parrafo2/parrafo.component';
import { ParrafoComponent3 } from './parrafo3/parrafo.component';

@NgModule({
  declarations: [
    AppComponent,
    ParrafoComponent2,
    ParrafoComponent3,
    ParrafoComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    TranslateModule.forRoot({
        loader: {
            provide: TranslateLoader,
            useFactory: (http: HttpClient) => {
                return new TranslateHttpLoader(http);
            },
            deps: [ HttpClient]
        }
    })
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
